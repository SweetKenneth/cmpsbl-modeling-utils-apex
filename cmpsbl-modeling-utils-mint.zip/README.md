# CMPSBL® Ascended Code Package

> Governed Cognitive Infrastructure · A PromptFluid™ Product

| Field | Value |
|-------|-------|
| **Serial** | `CMPSBL-MNRJ49SN-PC10` |
| **Fingerprint** | `7853cb1f9d8cc50a` |
| **CJPI Score** | 74/100 (Mint) |
| **Primitives** | 13 applied |
| **Language** | Python |
| **Generated** | 2026-04-09T13:45:50.351Z |

## What's Inside

| File | Purpose |
|------|---------|
| `src/original-source.txt` | Your original code (unmodified Layer 1) |
| `src/ascended-source.py` | Hardened code with primitive guards (Layer 2) |
| `PROOF.txt` | Cryptographic provenance certificate |
| `ascension-report.html` | Branded Ascension report |
| `docs/USER-GUIDE.html` | Deployment and testing guide |
| `docs/` | Pipeline details, capabilities, error codes, CJPI cert |
| `restoration-report.json` | Machine-readable report |
| `test-harness.config.json` | Config for @cmpsbl/test-harness |

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Verify This Artifact

**Online:** https://cmpsbl.com/verify/7853cb1f9d8cc50a
**Local:** Run the ascended source with `--verify` flag

## Intellectual Property

Inventor: Kenneth E. Sweet Jr.
U.S. Patent App. No. 64/029,678 · No. 64/031,637

## Support

Visit https://cmpsbl.com · Dev@CMPSBL.com · (760) FLUID-AI
Use your fingerprint ID (`7853cb1f9d8cc50a`) for instant lookup.

---
© 2026 PromptFluid™ · CMPSBL® · All rights reserved.