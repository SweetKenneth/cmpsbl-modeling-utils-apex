# Integration Guide — modeling_utils

> **Export Type:** Ascension Export
> **Generated:** 2026-04-09
> **Runtime:** CMPSBL® Convex Core™ Sealed Artifact
> **Zero Dependencies Required:** Yes — this export is fully self-contained.

This guide walks you through exactly how to place this ascension export into your existing stack, configure it for your environment, and verify it works correctly.

---

## 1. Prerequisites

Before integrating, ensure your environment meets these requirements:

| Requirement | Minimum | Recommended |
|------------|---------|-------------|
| Node.js | 18.x | 20.x or 22.x LTS |
| TypeScript | 5.0+ | 5.4+ |
| Package Manager | npm 9+ | pnpm 8+ or bun 1.x |
| Disk Space | 10 MB | 50 MB (with test artifacts) |

### Ascension-Specific Requirements

- The **original source file** you uploaded to Ascension (for reference)
- Your project's existing build pipeline (Webpack, Vite, esbuild, Rollup, etc.)
- If your original code was non-JS/TS: the appropriate language runtime for Layer 1 execution
  (e.g., Python 3.8+, Rust toolchain, Go 1.21+, PHP 8.0+)

---

## 2. What's In This Export

```
📦 modeling-utils/
├── 📄 manifest.json              ← Export metadata, CJPI score, primitive chain
├── 📁 _runtime/
│   ├── convex-core.ts     ← Convex Core™ (network-aware, offline-capable)
│   ├── chain-executor.ts         ← Sealed 40-primitive execution matrix
│   └── discovery-engine.ts       ← Template injection and synthesis reactor
├── 📁 src/
│   ├── original.*                ← Your original source code (UNTOUCHED)
│   ├── cognitive-overlay.ts      ← Layer 2: Discovered primitive augmentations
│   └── index.ts                  ← Unified entry point (Layer 1 + Layer 2)
├── 📁 tests/
│   ├── integration.test.ts       ← Verify both layers execute correctly
│   └── standalone.test.ts        ← Offline-mode validation
├── 📄 INTEGRATION.md             ← This file
├── 📄 README.md                  ← Auto-generated documentation
└── 📄 LICENSE                    ← Export license terms
```

### Key Files to Understand

| File | Purpose | Do You Edit It? |
|------|---------|----------------|
| `manifest.json` | Describes the export, its CJPI score, and primitive chain | ❌ No — read-only reference |
| `_runtime/convex-core.ts` | Self-contained runtime engine | ❌ No — sealed artifact |
| `src/index.ts` or `src/modeling-utils.ts` | Your entry point for using this capability | ✅ Yes — import from here |
| `tests/` | Pre-built verification suite | ✅ Yes — extend with your own tests |

---

## 3. Step-by-Step Integration

Choose the integration method that fits your workflow:

### Method A: Drop-In (Copy to Your Project)

Best for: Prototyping, air-gapped environments, or when you want full control.

**Step 1: Copy the export folder into your project**

```bash
# From your project root
cp -r ./modeling-utils/ ./src/lib/cmpsbl/modeling-utils/
```

**Step 2: Add the path alias (recommended)**

If using TypeScript with path aliases, add to your `tsconfig.json`:

```json
{
  "compilerOptions": {
    "paths": {
      "@cmpsbl/modeling-utils": ["./src/lib/cmpsbl/modeling-utils/src/index.ts"],
      "@cmpsbl/modeling-utils/*": ["./src/lib/cmpsbl/modeling-utils/src/*"]
    }
  }
}
```

**Step 3: Import and use**

```typescript
// With path alias
import { init, createPipeline } from '@cmpsbl/modeling-utils';

// Or with relative import
import { init, createPipeline } from './src/lib/cmpsbl/modeling-utils/src/index';

// Initialize (standalone — no network required)
const instance = init({ offline: true });

// Create a pipeline and execute
const pipeline = createPipeline(instance);
const result = await pipeline.execute({ your: 'input-data' });
console.log(result.output);
```

**Step 4: Verify the runtime loads**

```typescript
import { getRuntimeMode } from './src/lib/cmpsbl/modeling-utils/_runtime/convex-core';

// Should print 'offline' or 'hybrid' depending on network
console.log('Runtime mode:', getRuntimeMode());
```

### Method B: NPM / SDK (Recommended for Production)

Best for: Teams, CI/CD pipelines, automatic updates.

**Step 1: Install the SDK**

```bash
npm install @cmpsbl/sdk
# or
pnpm add @cmpsbl/sdk
# or
bun add @cmpsbl/sdk
```

**Step 2: Configure your API key**

```bash
# Option A: Environment variable (recommended for CI/CD)
export CMPSBL_API_KEY=pf_live_your_key_here

# Option B: .env file
echo "CMPSBL_API_KEY=pf_live_your_key_here" >> .env

# Option C: CLI login (stores in ~/.cmpsbl/credentials)
npx @cmpsbl/cli login
```

**Step 3: Import and use**

```typescript
import CMPSBL from '@cmpsbl/sdk';

const client = new CMPSBL(); // Auto-resolves credentials

// The modeling_utils capability activates automatically
// based on your subscription tier
const result = await client.execute({
  capability: 'modeling-utils',
  input: { your: 'data' },
});

console.log(result.output);
```

**Step 4: Verify activation**

```bash
npx @cmpsbl/cli status
# Should show: modeling_utils ✓ Active
```

### Method C: CLI Activation

Best for: Quick activation of subscription-included capabilities.

**Step 1: Install the CLI**

```bash
npm install -g @cmpsbl/cli
```

**Step 2: Authenticate**

```bash
cmpsbl login
```

**Step 3: Activate the capability**

```bash
cmpsbl ascension activate modeling-utils
```

**Step 4: Verify**

```bash
cmpsbl status
# ┌─────────────────────┬────────┬──────────┐
# │ Capability          │ Status │ Mode     │
# ├─────────────────────┼────────┼──────────┤
# │ modeling_utils      │ Active │ Hybrid   │
# └─────────────────────┴────────┴──────────┘
```

---

## 4. Framework-Specific Integration

### React / Next.js

```typescript
// hooks/use-modeling-utils.ts
import { useState, useCallback } from 'react';
import { init, createPipeline } from '@cmpsbl/modeling-utils';

const instance = init({ offline: false }); // hybrid mode

export function useModelingUtils() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const execute = useCallback(async (input: Record<string, any>) => {
    setLoading(true);
    try {
      const pipeline = createPipeline(instance);
      const output = await pipeline.execute(input);
      setResult(output);
      return output;
    } finally {
      setLoading(false);
    }
  }, []);

  return { execute, result, loading };
}
```

### Express / Node.js Server

```typescript
// routes/modeling-utils.ts
import { Router } from 'express';
import { init, createPipeline } from '@cmpsbl/modeling-utils';

const router = Router();
const instance = init({ offline: false });

router.post('/process', async (req, res) => {
  try {
    const pipeline = createPipeline(instance);
    const result = await pipeline.execute(req.body);
    res.json({ success: true, data: result.output });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
```

### Python (via Bridge Adapter)

If your stack is Python-based, use the bridge adapter pattern:

```python
# cmpsbl_bridge.py
import subprocess
import json

def execute_capability(input_data: dict) -> dict:
    """Execute the CMPSBL capability via the Node.js bridge."""
    result = subprocess.run(
        ['node', '-e', f"""
          const {{ init, createPipeline }} = require('./_runtime/convex-core');
          const instance = init({{ offline: true }});
          const pipeline = createPipeline(instance);
          pipeline.execute({json.dumps(input_data)}).then(r => {{
            process.stdout.write(JSON.stringify(r.output));
          }});
        """],
        capture_output=True, text=True, cwd='./lib/cmpsbl/modeling-utils'
    )
    return json.loads(result.stdout)

# Usage
result = execute_capability({"your": "data"})
print(result)
```

### Docker / Containerized Deployment

```dockerfile
# Include the export in your container
COPY ./modeling-utils/ /app/lib/cmpsbl/modeling-utils/

# Ensure Node.js is available for the runtime
RUN npm install --prefix /app/lib/cmpsbl/modeling-utils/ || true
```

---

## 5. Non-TypeScript Stacks — Bridge Adapters

This export includes language variants beyond TypeScript. Here's how the bridge adapter pattern works:

### How It Works

CMPSBL exports use TypeScript as the **canonical runtime** — all CJPI scoring, primitive chaining, and cognitive overlays execute in the JS/TS engine. When your stack is Python, Go, Rust, Java, or another language, a **bridge adapter** delegates execution to the TypeScript runtime and returns results to your native code.

```
┌──────────────────────────┐     HTTP/stdin      ┌────────────────────────┐
│  Your native code         │ ──────────────────→ │  CMPSBL Convex Core™ Sealed Artifact │
│  (Python, Go, Java, etc) │ ←────────────────── │  (Node.js / Bun)       │
└──────────────────────────┘     JSON result      └────────────────────────┘
```

### Why Not Native Execution?

The Convex Core™ Sealed Artifact contains the 40-primitive execution matrix, CJPI scoring engine, and discovery synthesis. These are **TypeScript-native** — they cannot be transpiled to Python or Go without losing fidelity. The bridge adapter ensures:

- ✅ **Exact same scoring** as the canonical runtime
- ✅ **Same primitive chain** execution order
- ✅ **Same offline/hybrid/network** mode behavior
- ✅ **Zero drift** between your stack and the substrate

### Bridge Adapter: Python

```python
# cmpsbl_bridge.py — Drop-in bridge for Python stacks
import subprocess, json, os

RUNTIME_DIR = os.path.join(os.path.dirname(__file__), '_runtime')

def execute(input_data: dict, offline: bool = True) -> dict:
    """Execute a CMPSBL capability via the TypeScript bridge."""
    script = f"""
      import {{ init, createPipeline }} from './convex-core.ts';
      const instance = init({{ offline: {str(offline).lower()} }});
      const pipeline = createPipeline(instance);
      const result = await pipeline.execute({json.dumps(input_data)});
      console.log(JSON.stringify(result.output));
    """
    proc = subprocess.run(
        ['npx', 'tsx', '-e', script],
        capture_output=True, text=True, cwd=RUNTIME_DIR
    )
    if proc.returncode != 0:
        raise RuntimeError(f"Bridge error: {proc.stderr.strip()}")
    return json.loads(proc.stdout)

# Usage
result = execute({"your": "data"})
print(result)
```

### Bridge Adapter: Go

```go
// cmpsbl_bridge.go — Execute CMPSBL via subprocess
package cmpsbl

import (
    "encoding/json"
    "os/exec"
    "path/filepath"
)

func Execute(input map[string]interface{}, runtimeDir string) (map[string]interface{}, error) {
    inputJSON, _ := json.Marshal(input)
    script := `
      import { init, createPipeline } from './convex-core.ts';
      const instance = init({ offline: true });
      const pipeline = createPipeline(instance);
      const result = await pipeline.execute(` + string(inputJSON) + `);
      console.log(JSON.stringify(result.output));
    `
    cmd := exec.Command("npx", "tsx", "-e", script)
    cmd.Dir = filepath.Join(runtimeDir, "_runtime")
    out, err := cmd.Output()
    if err != nil { return nil, err }
    var result map[string]interface{}
    json.Unmarshal(out, &result)
    return result, nil
}
```

### Bridge Adapter: HTTP Microservice

For production, run the runtime as a persistent microservice instead of spawning subprocesses:

```bash
# Start the bridge server (included in the export)
npx tsx _runtime/convex-core.ts --serve --port 3141

# Then call from any language via HTTP
curl -X POST http://localhost:3141/execute \
  -H "Content-Type: application/json" \
  -d '{"input": {"your": "data"}, "offline": false}'
```

### Execution Status Labels

When you see execution traces, each primitive reports its status honestly:

| Status | Meaning |
|--------|---------|
| `executed` | Ran natively in the JS/TS runtime |
| `delegated` | Scoring ran in TS; language-specific effects need server-side runtime |
| `unavailable` | Language not supported for this primitive |

> **Never fake execution.** If a primitive reports `delegated`, it means CJPI scoring
> and tiering happened correctly in TypeScript, but language-specific side effects
> (e.g., Python ML pipelines, Rust FFI) require your native runtime to handle.

---

## 6. Understanding the Convex Core™ Sealed Artifact (Black Box)

### Why Does Some Code Look Unreadable?

If you inspect your source files, you will notice that some code appears
obfuscated or uses hex-encoded constants. **This is intentional.** The Sealed Convex Core™
is merged directly into each source file for single-file drop-in usage. Here is why:

### What Is Sealed

| Component | Why It Is Protected | What You See |
|-----------|-------------------|--------------|
| **CJPI Scoring Weights** | Proprietary scoring formula | Hex arrays: `[0x1E, 0x1E, 0x14, 0x14]` |
| **Tier Thresholds** | IP-protected tier boundaries | Hex values: `[0x5C, 0x50, 0x41, 0x2D]` |
| **Synergy Multipliers** | Composability formulas | Computed at runtime, not stored in source |
| **Discovery Heuristics** | How capabilities are found | Not included in exports at all |
| **Internal Comments** | Architecture references | Stripped during export |

### What You CAN Verify

Despite the sealing, the runtime's **public API** is fully transparent:

```typescript
// These all work exactly as documented:
import { init, createPipeline, getRuntimeMode } from './_runtime/convex-core';

const instance = init({ offline: true });
console.log(instance.mode);          // 'offline' — transparent
console.log(instance.version);       // '1.x.x'  — transparent

const pipeline = createPipeline(instance);
const result = await pipeline.execute({ test: true });

console.log(result.output);          // your actual output
console.log(result.executionTrace);  // full primitive chain with statuses
console.log(result.cjpiScore);       // the computed score (value visible, formula sealed)
console.log(result.tier);            // 'Mythic', 'Prime', etc.
```

### Why You Cannot "Read" the Scoring Logic

The CJPI formula — how novelty, utility, complexity, and composability are weighted —
is CMPSBL's core intellectual property. The Convex Core™ artifact ensures:

1. **Consistency** — Every deployment scores identically, everywhere
2. **Tamper resistance** — No one can adjust weights to inflate scores
3. **IP protection** — The formula stays proprietary while the results stay transparent

### The Contract

> **You can verify every OUTPUT. You cannot inspect every FORMULA.**
>
> This is the same model used by credit scoring (FICO), search ranking (PageRank),
> and content recommendation engines. The results are auditable; the weights are not.

### How to Audit Without Source Access

```typescript
// Feed known inputs and verify deterministic outputs
const testCases = [
  { input: { novelty: 80, utility: 90, complexity: 70, composability: 85 }, expectedTier: 'Prime' },
  { input: { novelty: 95, utility: 95, complexity: 90, composability: 95 }, expectedTier: 'Mythic' },
];

for (const tc of testCases) {
  const result = await pipeline.execute(tc.input);
  console.assert(result.tier === tc.expectedTier,
    `Expected ${tc.expectedTier}, got ${result.tier}`);
}
// Deterministic: same input = same output, every time, on every machine.
```

---

## 8. Testing & Verification

### Quick Smoke Test

Run this immediately after integration to confirm everything works:

```bash
# From the export directory
npx tsx tests/integration.test.ts
```

### Manual Verification Checklist

Run through each of these checks after placing the files in your stack:

- [ ] **Import resolves** — No "module not found" errors when importing
- [ ] **Runtime initializes** — `init()` returns without throwing
- [ ] **Offline mode works** — `init({ offline: true })` succeeds without network
- [ ] **Pipeline executes** — `pipeline.execute({})` returns a result object
- [ ] **Manifest is valid** — `manifest.json` parses correctly and contains expected fields
- [ ] **No dependency conflicts** — Your existing `node_modules` has no version collisions

### Automated Test Script

Create this file in your project to run a full integration test:

```typescript
// tests/cmpsbl-integration.test.ts
import { describe, it, expect } from 'vitest'; // or jest, mocha, etc.
import { init, createPipeline } from '@cmpsbl/modeling-utils';

describe('modeling_utils Integration', () => {
  it('should initialize in offline mode', () => {
    const instance = init({ offline: true });
    expect(instance).toBeDefined();
    expect(instance.mode).toBe('offline');
  });

  it('should create a pipeline', () => {
    const instance = init({ offline: true });
    const pipeline = createPipeline(instance);
    expect(pipeline).toBeDefined();
    expect(typeof pipeline.execute).toBe('function');
  });

  it('should execute and return a result', async () => {
    const instance = init({ offline: true });
    const pipeline = createPipeline(instance);
    const result = await pipeline.execute({ test: true });

    expect(result).toBeDefined();
    expect(result.output).toBeDefined();
    expect(result.executionTrace).toBeDefined();
    expect(result.executionTrace.length).toBeGreaterThan(0);
  });

  it('should include CJPI score in execution trace', async () => {
    const instance = init({ offline: true });
    const pipeline = createPipeline(instance);
    const result = await pipeline.execute({ test: true });

    // Verify the primitive chain executed
    expect(result.executionTrace).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          primitive: expect.any(String),
          status: expect.stringMatching(/^(executed|delegated)$/),
        }),
      ])
    );
  });
});
```

### Runtime Mode Verification

```typescript
import { getRuntimeMode, configureEndpoint } from './_runtime/convex-core';

// Test each mode
console.log('Current mode:', getRuntimeMode()); // 'hybrid'

// Force offline
configureEndpoint(null);
console.log('Offline mode:', getRuntimeMode()); // 'offline'

// Test custom endpoint (self-hosted substrate)
configureEndpoint('https://your-substrate.internal/v1/substrate/primitive');
console.log('Custom mode:', getRuntimeMode()); // 'network'
```

### Health Check Endpoint (for Production)

Add this to your server to monitor the integration:

```typescript
app.get('/health/cmpsbl', async (req, res) => {
  try {
    const instance = init({ offline: true });
    const pipeline = createPipeline(instance);
    const result = await pipeline.execute({ healthcheck: true });

    res.json({
      status: 'healthy',
      capability: 'modeling-utils',
      mode: instance.mode,
      primitivesAvailable: result.executionTrace.length,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    res.status(503).json({
      status: 'unhealthy',
      error: err.message,
      timestamp: new Date().toISOString(),
    });
  }
});
```

---

## 7. Independent Verification & Trust

**No setup required.** Every verification method below works out of the box —
no API key, no subscription, no account needed. Just install and run.

### Method 1: `@cmpsbl/test-harness` (NPM Package)

The official test harness validates any CMPSBL export's integrity, scoring, and
primitive chain execution. Free, zero dependencies, works offline.

**Download:** https://www.npmjs.com/package/@cmpsbl/test-harness

```bash
# Install the test harness (free, zero dependencies)
npm install @cmpsbl/test-harness

# Run against your export directory
npx cmpsbl-verify ./modeling-utils/

# Expected output:
# +--------------------------------------------------+
# |  CMPSBL Export Verification Report               |
# +--------------------------------------------------+
# |  Manifest:        OK Valid                       |
# |  Runtime:          OK Loads (sealed, v1.x.x)     |
# |  Primitive Chain:  OK All primitives respond      |
# |  Offline Mode:     OK Functions without network   |
# |  Scoring:          OK Deterministic (CJPI)        |
# |  Integrity Hash:   OK Matches manifest fingerprint|
# +--------------------------------------------------+
```

> **What does the test harness check?**
> - `manifest.json` structure and required fields
> - Convex Core™ Sealed Artifact loads and initializes without errors
> - All primitives in the chain respond (executed or delegated)
> - Offline mode functions without any network calls
> - CJPI scoring produces deterministic results
> - File integrity hash matches the manifest fingerprint

### Method 2: CMPSBL CLI Verification

The CLI includes built-in verify and run commands. No subscription required for verification.

**Download:** https://www.npmjs.com/package/@cmpsbl/cli

```bash
# Install CLI (if not already)
npm install -g @cmpsbl/cli

# Verify an export directory
cmpsbl verify ./modeling-utils/

# Run the export in an isolated sandbox
cmpsbl run ./modeling-utils/ --input '{"test": true}' --offline

# Compare outputs across modes
cmpsbl run ./modeling-utils/ --input '{"test": true}' --mode offline
cmpsbl run ./modeling-utils/ --input '{"test": true}' --mode hybrid
# Both should produce identical scoring results
```

### Method 3: cmpsbl-daily-drop Repository (Community Verification)

We publish free Memory Stream artifacts daily to a public GitHub repository.
Clone it and run exports yourself to build confidence before integrating
paid capabilities. Same Convex Core™ artifact, same scoring engine, same executor.

**Repository:** https://github.com/SweetKenneth/cmpsbl-daily-drop

```bash
# Clone the daily drops repo
git clone https://github.com/SweetKenneth/cmpsbl-daily-drop.git
cd cmpsbl-daily-drop

# Install dependencies
npm install

# Run any drop to see real CMPSBL output
npx tsx drops/latest.ts

# Verify a drop with the test harness
npm install @cmpsbl/test-harness
npx cmpsbl-verify ./drops/latest/

# Compare your paid export against a known-good daily drop
npx cmpsbl-verify ./modeling-utils/ --compare ./drops/latest/
```

**Why this matters:** If the daily drops work (and they do — thousands of
developers have run them), your export uses the same runtime and will work too.
If you find a discrepancy, open an issue:
https://github.com/SweetKenneth/cmpsbl-daily-drop/issues

### Running Exports in CI/CD

Add CMPSBL verification to your pipeline to catch issues before deployment:

```yaml
# .github/workflows/verify-cmpsbl.yml
name: Verify CMPSBL Export
on: [push, pull_request]
jobs:
  verify:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20' }
      - run: npm install @cmpsbl/test-harness
      - run: npx cmpsbl-verify ./src/lib/cmpsbl/modeling-utils/
      - run: npx tsx ./src/lib/cmpsbl/modeling-utils/tests/integration.test.ts
```

### Trust Model Summary

| Question | Answer |
|----------|--------|
| Can I verify the output? | Yes — fully transparent results, traces, and scores |
| Can I read the scoring formula? | No — sealed IP (same as FICO, PageRank) |
| Can I test without paying? | Yes — use daily-drops repo or test-harness |
| Are results deterministic? | Yes — same input = same output, always |
| Can I run fully offline? | Yes — `init({ offline: true })` or `CMPSBL_OFFLINE=true` |
| Can I verify in CI/CD? | Yes — test-harness works in any Node.js environment |

### Still Stuck?

If verification fails or you need help integrating:

- **Email us:** support@cmpsbl.com — we respond within 24 hours
- **Documentation:** https://cmpsbl.com/developers
- **CLI diagnostics:** Run `cmpsbl doctor` for automated troubleshooting
- **Community:** https://github.com/SweetKenneth/cmpsbl-daily-drop/issues

---

## 9. Troubleshooting

### Common Issues

| Problem | Cause | Solution |
|---------|-------|---------|
| `Cannot find module` | Path alias not configured | Add the tsconfig path alias from Step 2 above |
| `init() is not a function` | Wrong import path | Import from `src/index.ts`, not from `_runtime/` |
| `Network timeout` | Substrate endpoint unreachable | Use `init({ offline: true })` or check firewall rules |
| `CJPI score is 0` | Running in offline mode without cached data | Execute once in hybrid/network mode to cache scores |
| `TypeScript errors` | Incompatible TS version | Ensure TypeScript 5.0+ in your project |
| `ESM/CJS conflict` | Module format mismatch | See the module format section below |

### Module Format (ESM vs CommonJS)

This export uses **ESM** (ES Modules) by default. If your project uses CommonJS:

```javascript
// CommonJS import
const { init, createPipeline } = require('./src/modeling-utils/src/index');

// Or add "type": "module" to your package.json for ESM
```

### Firewall / Proxy Configuration

If your environment uses a proxy or restricts outbound traffic:

```bash
# The Convex Core™ connects to this endpoint (when not in offline mode)
# Allow outbound HTTPS to:
#   https://api.cmpsbl.com/v1/substrate/primitive

# Or force offline mode (no network needed)
export CMPSBL_OFFLINE=true
```

### Getting Help

- **Documentation:** https://cmpsbl.com/developers
- **CLI diagnostics:** `cmpsbl doctor`
- **Email:** support@cmpsbl.com
- **Community:** https://github.com/SweetKenneth/cmpsbl-daily-drop/issues

---

## 10. Network Modes & Offline Execution

The Convex Core™ included in this export supports three execution modes:

| Mode | Primitives Available | Latency | When to Use |
|------|---------------------|---------|-------------|
| **Network** | Full 40-primitive deep effects | ~50ms | Production with substrate access |
| **Hybrid** (default) | Auto-fallback on network failure | Variable | Standard deployment |
| **Offline** | Local deterministic fallback | <1ms | Air-gapped, embedded, or edge |

### Configuring the Mode

```typescript
import { configureEndpoint, getRuntimeMode } from './_runtime/convex-core';

// Hybrid (default) — tries network, falls back to local
// No configuration needed

// Force offline — zero network calls
configureEndpoint(null);

// Self-hosted substrate
configureEndpoint('https://substrate.yourcompany.internal/v1/substrate/primitive');

// Verify
console.log(getRuntimeMode());
```

### Environment Variable Override

```bash
# Force offline mode globally
export CMPSBL_OFFLINE=true

# Custom endpoint
export CMPSBL_ENDPOINT=https://substrate.yourcompany.internal/v1/substrate/primitive
```

---

## 11. Upgrading & Re-Exporting

When you re-export from CMPSBL (after new discoveries or score changes):

1. **Back up** your current integration directory
2. **Replace** the `_runtime/` and `src/` directories with the new export
3. **Keep** any custom test files you added to `tests/`
4. **Re-run** the smoke test: `npx tsx tests/integration.test.ts`
5. **Compare** the new `manifest.json` with your backup to see what changed

```bash
# Quick diff to see changes
diff <(jq . old-backup/manifest.json) <(jq . modeling-utils/manifest.json)
```

### SDK Users

If using `@cmpsbl/sdk`, upgrades happen automatically:

```bash
npm update @cmpsbl/sdk
cmpsbl status  # Verify new capabilities
```

---

## What's Sealed & Protected

The following components are sealed (black-boxed) and cannot be modified:

- ⬛ CJPI scoring weight allocations
- ⬛ Auto-tiering threshold values
- ⬛ 40-primitive deep effect implementations
- ⬛ Synergy multiplier formulas
- ⬛ Discovery heuristics and synthesis templates

The public API surface is fully functional regardless of sealing.
The sealed components ensure consistent behavior across all deployments.

---

## Glossary

| Term | Meaning |
|------|---------|
| **CJPI** | Composable Joint Performance Index — scores artifacts on novelty, utility, complexity, and composability (0–100) |
| **Primitive** | One of the 40 foundational capabilities in the CMPSBL substrate |
| **Primitive Chain** | The sequence of primitives that execute for a given capability |
| **Convex Core™ Sealed Artifact** | The self-contained TypeScript engine bundled with every export |
| **Tier** | Score-based classification: Raw (0+), Mint (68+), Prime (80+), Relic (90+), Mythic (94+) |
| **Bridge Adapter** | A pattern for calling the TypeScript runtime from non-JS/TS languages |
| **Cognitive Overlay** | Layer 2 in Ascension exports — discovered primitive augmentations applied on top of your original code |
| **Execution Trace** | The log of which primitives ran and their status (executed, delegated, unavailable) |
| **Offline Mode** | Run the Convex Core™ Sealed Artifact with zero network calls — all scoring happens locally |
| **Hybrid Mode** | Default — tries network for deep effects, falls back to local if unavailable |
| **Memory Stream** | Autonomous 8-hour discovery cycle that surfaces new capabilities |
| **Ascension** | The process of enriching your code with discovered substrate capabilities |
| **Discovery** | A newly found capability surfaced by the Memory Stream |

---

## Support & Resources

| Resource | Link |
|----------|------|
| **Documentation** | https://cmpsbl.com/developers |
| **Support Email** | support@cmpsbl.com |
| **NPM Packages** | https://www.npmjs.com/org/cmpsbl |
| **Test Harness** | https://www.npmjs.com/package/@cmpsbl/test-harness |
| **CLI** | https://www.npmjs.com/package/@cmpsbl/cli |
| **Daily Drops (Free)** | https://github.com/SweetKenneth/cmpsbl-daily-drop |
| **CLI Diagnostics** | Run `cmpsbl doctor` in your terminal |

---

© 2025–2026 PromptFluid®. All rights reserved.
CMPSBL® and Convex Core™ Sealed Artifact are trademarks of PromptFluid.
